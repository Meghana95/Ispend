<?php
error_reporting(E_ALL);
require("class.phpmailer.php");

		require_once('dbConnect.php');
  
	   
	 $date_c = date("y/m/d") ;
	echo "Today is " . $date_c . "<br>";
 $query1 = "SELECT category, offer, datefrom, dateto from offers where 

datefrom='$date_c'";
       
$cardno="4532737569523661";
$result1 = mysqli_query( $con, $query1 );
    if ( mysqli_num_rows( $result1 ) > 0 ) {
             while ( $row = mysqli_fetch_assoc( $result1 ) )
                 { echo "<br>";
                   $res1 = $row[ 'category' ] . "-" . $row[ 'offer' ] . "-" . $row['datefrom' ] . $row[ 'dateto' ] . ",";
				 echo "$res1 ";

$email_q="SELECT emailid from bank_db where cardno='$cardno'";   
$name_q="SELECT name from bank_db where cardno='$cardno'";      
$email = mysqli_fetch_array(mysqli_query($con,$email_q));
$name = mysqli_fetch_array(mysqli_query($con,$name_q)); 
echo $name[0];
echo $email[0];     



$mail = new PHPMailer();
//$mail->IsSMTP(); // set mailer to use SMTP
$mail->SMTPDebug  = 2; 
$mail->From = "ispendofficial@gmail.com";
$mail->FromName = "ISpend";
$mail->Host = "smtp.gmail.com"; // specif smtp server
$mail->SMTPSecure= "ssl"; // Used instead of TLS when only POP mail is selected
$mail->Port = 465; // Used instead of 587 when only POP mail is selected
$toadd=$email[0];
echo $toadd;

$mail->SMTPAuth = true;
$mail->Username = "ispendofficial@gmail.com"; // SMTP username
$mail->Password = "ispend2016"; // SMTP password
$mail->AddAddress($toadd,$name[0]); //replace myname and mypassword to yours
$mail->AddReplyTo("ispendofficial@gmail.com", "ISpend");
$mail->WordWrap = 50; // set word wrap
//$mail->AddAttachment("c:\\temp\\js-bak.sql"); // add attachments
//$mail->AddAttachment("c:/temp/11-10-00.zip");

$mail->IsHTML(true); // set email format to HTML
$mail->Subject = 'OFFERS-ISPEND';
$mail->Body = '
<html>
<html>
<head>
  <title>Offers</title>

</head>
<body>
  <p><b>Greetings '.$name[0].'!</!</b></p>
  <table>
<tr>
<th>We have some exciting offers for you in '.$row[ 'category' ].'  starting from today!!</th>
</tr>
<tr>
<td align=center style="font-size: 200%;
width:600px;
height:60px;
padding:20px;
border:6px outset orange;
background-color:#FFF5EE
">&nbsp; '.$row['offer'].'<sup>*</sup></td>
</tr>
<tr>
<td align=right><sup>*</sup>offer valid only till '.$row[ 'dateto' ].'</td>
</tr>
</table>
<p>Regards, </p>
<p>ISpend </p>
</body>
</html> ';

if($mail->Send()) {echo "Send mail successfully";}
else {echo "Send mail fail";}  
          
 } 
     
                        $res1 = rtrim($res1,',');        } 
        else {
                        echo "No offers today";
        }


echo "<br>";

            mysqli_close( $con );
?>
