<?php
			require_once('dbConnect.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
		
		
		$userid = $_POST['userid'];
		
			$sql = "SELECT cardno FROM bank_db where userid='$userid'"; 
                        
                        $result = mysqli_query($con, $sql);
                           
                        $json=array();
                      while($row = mysqli_fetch_assoc($result))
                       {
                          $json['info'][]=$row;
                       }
                               
			
                    echo json_encode($json); 
                        echo "hello";
                       mysqli_close($con);
		}
}else{
echo 'error';
}			
		
?>