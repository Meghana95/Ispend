<?php

define('HOST','mysql.hostinger.in');
define('USERNAME','u961619150_ispen');
define('PASSWORD','ispend');
define('DB','u961619150_ispen');

$con=mysqli_connect(HOST,USERNAME,PASSWORD,DB) or die('Unable to Connect');
?>
