<?php
error_reporting(E_ALL);
require('class.phpmailer.php');
 $userid = '30';
 require_once('dbConnect.php');
 $sql="SELECT emailid FROM bank_db WHERE userid='$userid'";
 $name_s = "SELECT name from bank_db WHERE userid='$userid'";
 $card="SELECT cardno from bank_db WHERE userid='$userid'";
$c=mysqli_fetch_array(mysqli_query($con,$card));
$pass="SELECT password from signup WHERE cardno='$c[0]'";
$p=mysqli_fetch_array(mysqli_query($con,$pass));
 $check = mysqli_fetch_array(mysqli_query($con,$sql));
 if(isset($check))
  {
    $name = mysqli_fetch_array(mysqli_query($con,$name_s)); 
	$to = mysqli_fetch_array(mysqli_query($con,$sql));
	$mail = new PHPMailer();
//$mail->IsSMTP(); // set mailer to use SMTP
$mail->SMTPDebug  = 2; 
$mail->From = "ispendofficial@gmail.com";
$mail->FromName = "ISpend";
$mail->Host = "smtp.gmail.com"; // specif smtp server
$mail->SMTPSecure= "ssl"; // Used instead of TLS when only POP mail is selected
$mail->Port = 465; // Used instead of 587 when only POP mail is selected
//$toadd="mdfahdfurqan@gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "ispendofficial@gmail.com"; // SMTP username
$mail->Password = "ispend2016"; // SMTP password
$mail->AddAddress($to[0], $name[0]); //replace myname and mypassword to yours
$mail->AddReplyTo("ispendofficial@gmail.com", "ISpend");
$mail->WordWrap = 50; // set word wrap
$mail->IsHTML(true); // set email format to HTML
$mail->Subject = 'Password Reset-ISPEND';
$mail->Body = '
<html>
<head>
</head>
<body>
  <table>
  <tr>
<th>Your password is : </th>
</tr>
<tr>
<td>'.$p[0].'</td>
</tr>
</table>

<p>Regards, </p>
<p>ISpend </p>
</body>
</html>
';

if($mail->Send()) {echo 'mail sent';}
else {echo 'not sent';} 

  }
 else{ 
	 echo 'No such user exists!';
	 }
 mysqli_close($con);


?>
