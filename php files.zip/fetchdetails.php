<?php
        define( 'HOST', 'mysql.hostinger.in' );
        define( 'USERNAME', 'u961619150_ispen' );
        define( 'PASSWORD', 'ispend' );
        define( 'DB', 'u961619150_ispen' );
        $con = mysqli_connect( HOST, USERNAME, PASSWORD, DB ) or die( 'Unable to Connect' );
        $cardno = $_POST['cardno'];
        $cardno = preg_replace( '/\s+/', '', $cardno );
        $date1  = $_POST['date1'];
        $date2  = $_POST['date2'];
        $fdate  = date( 'Y-m-d', strtotime( $date1 ) );
        $tdate  = date( 'Y-m-d', strtotime( $date2 ) );
        $query  = "SELECT category, store_details, amount, trans_date from transaction WHERE cardno='$cardno' AND trans_date BETWEEN '$fdate' AND '$tdate'";
        $result = mysqli_query( $con, $query );
        if ( mysqli_num_rows( $result ) > 0 ) {
                        while ( $row = mysqli_fetch_assoc( $result ) ) {
                                        $res .= $row[ 'category' ] . "&" . $row[ 'store_details' ] . "&" . $row[ 'amount' ] . "&" . $row[ 'trans_date' ] . ",";
                        } 
                        $res = rtrim($res,',');
                        echo $res;
        } 
        else {
                        echo "No results";
        }
        mysqli_close( $con );
?>            
