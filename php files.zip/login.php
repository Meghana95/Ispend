<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$userid = $_POST['userid'];
		$password = $_POST['password'];
		if($userid == '' || $password == ''){
				echo "Error:please fill all values";
		}else{
		require_once('dbConnect.php');
		$cno1="SELECT cardno from bank_db WHERE userid='$userid'";
		$check1 = mysqli_fetch_array(mysqli_query($con,$cno1));
		$cno2 = "SELECT cardno from signup where password='$password'";
		$check2 = mysqli_fetch_array(mysqli_query($con,$cno2));
		
		if($check1[0]==$check2[0]){
			                   
						$sql1 = "UPDATE bank_db SET status='Active' WHERE cardno='$check1[0]'";
						mysqli_query($con,$sql1);
						$query  = "SELECT cardno,userid,name,contact,emailid from bank_db WHERE cardno='$check1[0]'";
						$result = mysqli_query( $con, $query );
						if ( mysqli_num_rows( $result ) > 0 ) {
                                                                                       while ( $row = mysqli_fetch_assoc( $result ) ) {
                                                                                       $res .= $row[ 'cardno' ] . "&" . $row[ 'userid' ] . "&" . $row[ 'name' ] . "&" . $row[ 'contact' ] . "&" . $row[ 'emailid' ] . ",";
                                                } 
                                                $res = rtrim($res,',');
                                                echo $res;
               } 

		}else{
			echo "Error:Invalid Username or Password";
		}
		}
	}else{
		echo "Error: try again";
	}
mysqli_close($con);
?>			