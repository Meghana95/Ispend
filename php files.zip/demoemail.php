<?php
error_reporting(E_ALL);
require("class.phpmailer.php");

		require_once('dbConnect.php');
$mail = new PHPMailer();
//$mail->IsSMTP(); // set mailer to use SMTP
$mail->SMTPDebug  = 2; 
$mail->From = "ispendofficial@gmail.com";
$mail->FromName = "ISpend";
$mail->Host = "smtp.gmail.com"; // specif smtp server
$mail->SMTPSecure= "ssl"; // Used instead of TLS when only POP mail is selected
$mail->Port = 465; // Used instead of 587 when only POP mail is selected
$toadd=$to[0];
echo $toadd;
$name1="Fahd";
$mail->SMTPAuth = true;
$mail->Username = "ispendofficial@gmail.com"; // SMTP username
$mail->Password = "ispend2016"; // SMTP password
$mail->AddAddress($toadd,$name[0]); //replace myname and mypassword to yours
$mail->AddReplyTo("ispendofficial@gmail.com", "ISpend");
$mail->WordWrap = 50; // set word wrap
//$mail->AddAttachment("c:\\temp\\js-bak.sql"); // add attachments
//$mail->AddAttachment("c:/temp/11-10-00.zip");

$mail->IsHTML(true); // set email format to HTML
$mail->Subject = 'YOUR MONTHLY REPORT-ISPEND';

$mail->Body = '
<html>
<head>
  <title>Report</title>
  


</head>
<body>
  <p><b>Greetings '.$name[0].'!</b></p>
<h3> Here is your Monthly report of Your Expenditure through Your Card-'.$cardno.'! </h3>

<table style="border-collapse:collapse;border-spacing:0;border-color:#999
"><centre>
  <tr>
    <th style="font-family:Comic Sans MS, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4">Sno</th>
    <th style="font-family:Comic Sans MS, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4">Category</th>
    <th style="font-family:Comic Sans MS, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4">Amount Spent</th>
    <th style="font-family:Comic Sans MS, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4">Date</th>
    <th style="font-family:Comic Sans MS, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#fff;background-color:#26ADE4">Store Details</th>
  </tr> ';

	if ( mysqli_num_rows( $result ) > 0) { $i=1;
             while ( $row1 = mysqli_fetch_assoc( $result ) ) 
{ 

 $mail->Body.= '<tr>
    <td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;text-align:center;vertical-align:top">'.$i++ .' </td>
    <td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;text-align:center;vertical-align:top">'. $row1[ 'category' ].' </td>
    <td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;text-align:center;vertical-align:top"> Rs.'. $row1[ 'amount' ].'</td>
    <td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;text-align:center;vertical-align:top">'. $row1[ 'trans_date' ].' </td>
    <td style="font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#999;color:#444;background-color:#F7FDFA;text-align:center;vertical-align:top">'. $row1[ 'store_details' ].'</td>
  </tr>';


}}
 
$mail->Body.='</centre>

</table>
<p>Regards, </p>
<p>ISpend </p>
</body>
</html> ';

if($mail->Send()) {echo "Send mail successfully";}
else {echo "Send mail fail";} 

          ?>
 
     