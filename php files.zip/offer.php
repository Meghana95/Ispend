<?php
        define( 'HOST', 'mysql.hostinger.in' );
        define( 'USERNAME', 'u961619150_ispen' );
        define( 'PASSWORD', 'ispend' );
        define( 'DB', 'u961619150_ispen' );
        $con = mysqli_connect( HOST, USERNAME, PASSWORD, DB ) or die( 'Unable to Connect' );
        $query  = "SELECT category, offer, datefrom, dateto from offers";
        $result = mysqli_query( $con, $query );
        if ( mysqli_num_rows( $result ) > 0 ) {
                        while ( $row = mysqli_fetch_assoc( $result ) ) {
                                        $res .= $row[ 'category' ] . "&" . $row[ 'offer' ] . "&" . $row[ 'datefrom' ] . "&" . $row[ 'dateto' ] . ",";
                        } 
                        $res = rtrim($res,',');
                        echo $res;
        } 
        else {
                        echo "No offers";
        }
        mysqli_close( $con );
?>            
