<?php
error_reporting(E_ALL);
require('class.phpmailer.php');

if($_SERVER['REQUEST_METHOD']=='POST'){
 $cardno = $_POST['cardno'];
 $password = $_POST['password'];

 
 if($cardno == '' || $password == ''){
 echo 'please fill all values';
 }else{
 require_once('dbConnect.php');
 $sql = "SELECT * FROM signup WHERE cardno='$cardno'";

 
 $check = mysqli_fetch_array(mysqli_query($con,$sql));
 
 if(isset($check))
  {
	 echo 'User already exists';
  }
 else{ 
	 $sql = "INSERT INTO signup (cardno,password) 	VALUES('$cardno','$password')";
	 $sql1 = "UPDATE bank_db SET status='Signedup-NotVerified' WHERE cardno='$cardno'";
 	if(mysqli_query($con,$sql) && mysqli_query($con,$sql1))
	{
 		 echo 'successfully registered';

$userid_s="SELECT userid from bank_db WHERE cardno='$cardno'";
$userid = mysqli_fetch_array(mysqli_query($con,$userid_s));
	
$to_s = "SELECT emailid from bank_db WHERE cardno='$cardno'";
$to = mysqli_fetch_array(mysqli_query($con,$to_s));

$name_s = "SELECT name from bank_db WHERE cardno='$cardno'";
$name = mysqli_fetch_array(mysqli_query($con,$name_s)); 

$mail = new PHPMailer();
//$mail->IsSMTP(); // set mailer to use SMTP
$mail->SMTPDebug  = 2; 
$mail->From = "ispendofficial@gmail.com";
$mail->FromName = "ISpend";
$mail->Host = "smtp.gmail.com"; // specif smtp server
$mail->SMTPSecure= "ssl"; // Used instead of TLS when only POP mail is selected
$mail->Port = 465; // Used instead of 587 when only POP mail is selected
//$toadd="mdfahdfurqan@gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "ispendofficial@gmail.com"; // SMTP username
$mail->Password = "ispend2016"; // SMTP password
$mail->AddAddress($to[0], $name[0]); //replace myname and mypassword to yours
$mail->AddReplyTo("ispendofficial@gmail.com", "ISpend");
$mail->WordWrap = 50; // set word wrap
$mail->IsHTML(true); // set email format to HTML
$mail->Subject = 'Verification-ISPEND';
$mail->Body = '
<html>
<head>
  <title>User Registered</title>
</head>
<body>
  <p>Thank you for Registering!</p>
  <table>
<tr>
<th>This is your User ID</th>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$userid[0].'</td>
</tr>
</table>

<p>Regards, </p>
<p>ISpend </p>
</body>
</html>
';

if($mail->Send()) {}
else { echo 'Invalid Card Number';} 

	 }
 	else{
  	echo 'Invalid Card Number';
	 }
    }
 mysqli_close($con);
 }
}else{
echo 'error';
}
?>
